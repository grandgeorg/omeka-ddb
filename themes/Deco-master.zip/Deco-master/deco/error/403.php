<?php head(array('title'=>'403','bodyid'=>'403')); ?>

<div id="primary">	
<h2>Oops!</h2>	

	<p>Sorry, you don't have permission to view this page.</p>
	
</div><!-- end primary -->

<?php foot(); ?>

